﻿# TrinityWar Schema Backup 2026-06-09T17-04-46

This backup contains database structure only:

- prisma/schema.prisma
- prisma/migrations/**
- postgres-schema.sql

It does not include table data, robot logs, player state, wallet logs, raid orders, or JSON data backup.

## Source

- Provider: PostgreSQL
- Host: localhost
- Port: 5432
- Database: trinitywar
- Schema: public

## Summary

- Local migrations: 56
- Latest migration: 056_robot_sim_snapshots
- _prisma_migrations rows: 60
- Rolled-back migration rows: 4
- Public base tables: 66
- postgres-schema.sql bytes: 133847
- postgres-schema.sql sha256: 2614D4F99FDCFC398B8F5B854C6F9B15498D2F1E7924639A178632B14F926DD1

## Restore Notes

Copy prisma/schema.prisma and prisma/migrations into services/game-server/prisma, set DATABASE_URL, then run:

`powershell
npm run prisma:generate --workspace @trinitywar/game-server
npx prisma migrate deploy --schema services/game-server/prisma/schema.prisma
`

postgres-schema.sql is included for direct PostgreSQL schema inspection or manual schema restore. It is a schema-only dump generated with pg_dump --schema-only --no-owner --no-privileges --schema=public.
